import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import { Dashboard } from "@/pages/Dashboard";
import { AddTransaction } from "@/pages/AddTransaction";
import { Placeholder } from "@/pages/Placeholder";

const router = createBrowserRouter([
  {
    path: "/",
    element: <AppLayout />,
    children: [
      { index: true, element: <Dashboard /> },
      { path: "add", element: <AddTransaction /> },
      {
        path: "transactions",
        element: <Placeholder title="Συναλλαγές" description="Λίστα όλων των συναλλαγών — υπό κατασκευή." />,
      },
      {
        path: "recurring",
        element: <Placeholder title="Πάγια έσοδα/έξοδα" description="Recurring templates — υπό κατασκευή." />,
      },
      {
        path: "vat",
        element: <Placeholder title="Σύνοψη ΦΠΑ" description="Τριμηνιαία ανάλυση — υπό κατασκευή." />,
      },
      {
        path: "forecast",
        element: <Placeholder title="Forecast" description="Προβολή 12 μηνών — υπό κατασκευή." />,
      },
      {
        path: "settings",
        element: <Placeholder title="Ρυθμίσεις" description="Προτιμήσεις & εξαγωγές — υπό κατασκευή." />,
      },
    ],
  },
]);

export function App() {
  return <RouterProvider router={router} />;
}

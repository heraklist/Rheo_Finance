import { getDb } from "@/lib/db";
import type { Account, Book, Category, Tag } from "@/lib/types";

export async function listBooks(): Promise<Book[]> {
  const db = await getDb();
  return db.select<Book[]>("SELECT * FROM books ORDER BY slug");
}

export async function listAccounts(bookId?: string): Promise<Account[]> {
  const db = await getDb();
  if (bookId) {
    return db.select<Account[]>(
      "SELECT * FROM accounts WHERE book_id = ? AND is_archived = 0 ORDER BY type, name",
      [bookId],
    );
  }
  return db.select<Account[]>(
    "SELECT * FROM accounts WHERE is_archived = 0 ORDER BY book_id, type, name",
  );
}

export async function listCategories(opts: {
  bookId?: string;
  type?: "income" | "expense" | "reserve" | "transfer";
} = {}): Promise<Category[]> {
  const db = await getDb();
  const conditions: string[] = ["is_archived = 0"];
  const params: string[] = [];

  if (opts.bookId) {
    conditions.push("book_id = ?");
    params.push(opts.bookId);
  }
  if (opts.type) {
    conditions.push("type = ?");
    params.push(opts.type);
  }

  return db.select<Category[]>(
    `SELECT * FROM categories WHERE ${conditions.join(" AND ")}
     ORDER BY sort_order, name`,
    params,
  );
}

export async function listTags(): Promise<Tag[]> {
  const db = await getDb();
  return db.select<Tag[]>(
    "SELECT * FROM tags WHERE is_archived = 0 ORDER BY name",
  );
}
